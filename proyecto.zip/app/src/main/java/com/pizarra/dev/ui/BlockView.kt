package com.pizarra.dev.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.TabStopSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Un bloque del lienzo (título, subtítulo o nota). La tarjeta se dibuja dentro de un margen (pad)
 * donde viven los 4 anclajes, así todo el bloque recibe toques sin salirse de sus límites.
 * Posición: wx,wy = esquina de la tarjeta en coordenadas de mundo. Es el BoardView quien lo traslada/escala.
 */
class BlockView(
    ctx: Context,
    val bid: Long,
    val type: Int,
    var wx: Float,
    var wy: Float,
    var cardW: Int,
    text: String,
    var code: Boolean
) : FrameLayout(ctx) {

    interface Host {
        fun scale(): Float
        fun onMoved(b: BlockView)
        fun onMoveEnd(b: BlockView)
        fun onResizeEnd(b: BlockView)
        fun onDelete(b: BlockView)
        fun onText(b: BlockView, t: String)
        fun onCode(b: BlockView)
        fun onFocus(b: BlockView)
        fun onLinkStart(b: BlockView, side: Int)
        fun onLinkMove(x: Float, y: Float)
        fun onLinkEnd(x: Float, y: Float, commit: Boolean)
    }

    companion object {
        const val TITLE = 0
        const val SUBTITLE = 1
        const val NOTE = 2
    }

    var host: Host? = null
    val pad = dp(16)
    val edit = EditText(ctx)

    private val rad = dpf(10f)
    private val body = FrameLayout(ctx)
    private val scroll = HorizontalScrollView(ctx)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dpf(1.5f) }
    private val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.BG }
    private val dotLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Ui.ACCENT; strokeWidth = dpf(1.5f) }

    private var tab: TabStopSpan.Standard? = null
    private var busy = false
    private var nl = -1
    private var dirty = false
    private var linking = false
    private var lrx = 0f
    private var lry = 0f

    private val btnTab = tv("TAB") { insertTab() }
    private val btnMode = tv("</>") { code = !code; applyMode(); host?.onCode(this); edit.requestFocus() }
    private val btnDel = tv("×") { host?.onDelete(this) }
    private val grab = TextView(ctx)
    private val saveRun = Runnable { flush() }

    private val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {
            nl = if (type == NOTE && code && !busy && before == 0 && count == 1 && s != null && s[st] == '\n') st else -1
        }
        override fun afterTextChanged(e: Editable) {
            if (busy) return
            busy = true
            if (nl >= 0) autoIndent(e, nl)
            nl = -1
            ensureTabs(e)
            busy = false
            dirty = true
            removeCallbacks(saveRun)
            postDelayed(saveRun, 700)
        }
    }

    init {
        setWillNotDraw(false)
        setPadding(pad, pad, pad, pad)

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        grab.apply {
            this.text = "≡"
            setTextColor(Ui.DIM)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(grab, LinearLayout.LayoutParams(0, dp(28), 1f))
        if (type == NOTE) {
            header.addView(btnTab, LinearLayout.LayoutParams(WRAP, dp(28)))
            header.addView(btnMode, LinearLayout.LayoutParams(WRAP, dp(28)))
        }
        header.addView(btnDel, LinearLayout.LayoutParams(WRAP, dp(28)))

        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        addView(Grip(ctx), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.END or Gravity.BOTTOM))

        val initial = text
        edit.apply {
            background = null
            setPadding(dp(10), dp(2), dp(10), dp(10))
            gravity = Gravity.TOP or Gravity.START
            minHeight = dp(if (type == NOTE) 96 else 44)
            setHintTextColor(Ui.DIM)
            setText(initial)
            setOnFocusChangeListener { _, f -> this@BlockView.invalidate(); if (f) host?.onFocus(this@BlockView) }
            setOnKeyListener { _, k, ev ->
                if (code && k == KeyEvent.KEYCODE_TAB && ev.action == KeyEvent.ACTION_DOWN) { insertTab(); true } else false
            }
        }
        if (type != NOTE) code = false
        applyMode()
        edit.addTextChangedListener(watcher)

        // Arrastrar el bloque desde la barra superior (≡)
        grab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lrx = e.rawX; lry = e.rawY
                    parent?.requestDisallowInterceptTouchEvent(true)
                    bringToFront()
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = host?.scale() ?: 1f
                    wx += (e.rawX - lrx) / s
                    wy += (e.rawY - lry) / s
                    lrx = e.rawX; lry = e.rawY
                    host?.onMoved(this)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> host?.onMoveEnd(this)
            }
            true
        }
    }

    private fun tv(t: String, f: () -> Unit) = TextView(context).apply {
        this.text = t
        setTextColor(Ui.ACCENT)
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { f() }
    }

    /** Alterna entre modo texto (word wrap) y modo código (monoespaciado, sin wrap, scroll horizontal). */
    private fun applyMode() {
        val isCode = type == NOTE && code
        (edit.parent as? ViewGroup)?.removeView(edit)
        scroll.removeAllViews()
        body.removeAllViews()
        tab?.let { edit.text.removeSpan(it) }
        tab = null

        edit.setTextColor(Ui.TEXT)
        if (isCode) {
            edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            edit.setHorizontallyScrolling(true)      // siempre DESPUÉS de inputType
            edit.typeface = Typeface.MONOSPACE
            edit.textSize = 13f
            edit.hint = "// código"
            tab = TabStopSpan.Standard(max(1, (edit.paint.measureText("0") * 4).toInt()))
            scroll.isFillViewport = true
            scroll.isHorizontalScrollBarEnabled = false
            scroll.addView(edit, FrameLayout.LayoutParams(WRAP, WRAP))
            body.addView(scroll, FrameLayout.LayoutParams(MATCH, WRAP))
            ensureTabs(edit.text)
        } else {
            edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            edit.setHorizontallyScrolling(false)
            edit.typeface = if (type == NOTE) Typeface.DEFAULT else Typeface.DEFAULT_BOLD
            edit.textSize = when (type) { TITLE -> 26f; SUBTITLE -> 19f; else -> 14f }
            edit.hint = when (type) { TITLE -> "Título"; SUBTITLE -> "Subtítulo"; else -> "Escribe una nota…" }
            body.addView(edit, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        edit.setTextColor(if (type == SUBTITLE) Ui.GREEN else Ui.TEXT)
        btnTab.visibility = if (isCode) View.VISIBLE else View.GONE
        btnMode.text = if (isCode) "Aa" else "</>"
        invalidate()
    }

    private fun ensureTabs(e: Editable) {
        val sp = tab ?: return
        if (e.getSpanStart(sp) != 0 || e.getSpanEnd(sp) != e.length) {
            e.setSpan(sp, 0, e.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        }
    }

    private fun insertTab() {
        val a = max(0, min(edit.selectionStart, edit.selectionEnd))
        val b = max(0, max(edit.selectionStart, edit.selectionEnd))
        edit.text.replace(a, b, "\t")
        edit.setSelection(a + 1)
    }

    /** Mantiene la indentación de la línea anterior; añade un nivel tras { [ ( : */
    private fun autoIndent(e: Editable, nlPos: Int) {
        var ls = nlPos
        while (ls > 0 && e[ls - 1] != '\n') ls--
        var i = ls
        while (i < nlPos && (e[i] == ' ' || e[i] == '\t')) i++
        var j = nlPos - 1
        while (j >= i && (e[j] == ' ' || e[j] == '\t')) j--
        val last = if (j >= i) e[j] else ' '
        val ins = e.subSequence(ls, i).toString() + (if (last in "{[(:") "\t" else "")
        if (ins.isNotEmpty()) {
            e.insert(nlPos + 1, ins)
            edit.setSelection(nlPos + 1 + ins.length)
        }
    }

    fun flush() {
        removeCallbacks(saveRun)
        if (dirty) {
            dirty = false
            host?.onText(this, edit.text.toString())
        }
    }

    // ---- anclajes: 0 arriba, 1 derecha, 2 abajo, 3 izquierda ----
    private fun ax(side: Int): Float = when (side) { 1 -> (width - pad).toFloat(); 3 -> pad.toFloat(); else -> width / 2f }
    private fun ay(side: Int): Float = when (side) { 0 -> pad.toFloat(); 2 -> (height - pad).toFloat(); else -> height / 2f }

    private fun anchorAt(x: Float, y: Float): Int {
        val r = dpf(14f)
        for (k in 0..3) {
            val dx = x - ax(k)
            val dy = y - ay(k)
            if (dx * dx + dy * dy <= r * r) return k
        }
        return -1
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val side = anchorAt(e.x, e.y)
            if (side >= 0) {
                linking = true
                parent?.requestDisallowInterceptTouchEvent(true)
                host?.onLinkStart(this, side)
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!linking) return false
        val x = wx - pad + e.x
        val y = wy - pad + e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> host?.onLinkMove(x, y)
            MotionEvent.ACTION_UP -> { linking = false; host?.onLinkEnd(x, y, true) }
            MotionEvent.ACTION_CANCEL -> { linking = false; host?.onLinkEnd(x, y, false) }
        }
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        host?.onMoved(this)     // la altura cambia al escribir: redibuja las líneas
    }

    override fun onDraw(c: Canvas) {
        val l = pad.toFloat()
        val r = (width - pad).toFloat()
        val b = (height - pad).toFloat()
        fill.color = if (type == NOTE && code) Ui.CODE_BG else Ui.SURFACE
        line.color = when {
            edit.hasFocus() -> Ui.FOCUS
            type == TITLE -> Ui.ACCENT
            type == SUBTITLE -> Ui.GREEN
            else -> Ui.STROKE
        }
        c.drawRoundRect(l, l, r, b, rad, rad, fill)
        c.drawRoundRect(l, l, r, b, rad, rad, line)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val rd = dpf(5f)
        for (k in 0..3) {
            c.drawCircle(ax(k), ay(k), rd, dotFill)
            c.drawCircle(ax(k), ay(k), rd, dotLine)
        }
    }

    /** Asa inferior derecha: cambia el ancho de la tarjeta. */
    private inner class Grip(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Ui.DIM; strokeWidth = dpf(1.5f); strokeCap = Paint.Cap.ROUND
        }
        private var lx = 0f

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawLine(w * 0.85f, h * 0.35f, w * 0.35f, h * 0.85f, p)
            c.drawLine(w * 0.85f, h * 0.65f, w * 0.65f, h * 0.85f, p)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lx = e.rawX
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = host?.scale() ?: 1f
                    val nw = max(dp(140), cardW + ((e.rawX - lx) / s).toInt())
                    if (nw != cardW) {
                        cardW = nw
                        lx = e.rawX
                        val lp = this@BlockView.layoutParams
                        if (lp != null) {
                            lp.width = cardW + 2 * pad
                            this@BlockView.requestLayout()
                        }
                        host?.onMoved(this@BlockView)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> host?.onResizeEnd(this@BlockView)
            }
            return true
        }
    }
}
